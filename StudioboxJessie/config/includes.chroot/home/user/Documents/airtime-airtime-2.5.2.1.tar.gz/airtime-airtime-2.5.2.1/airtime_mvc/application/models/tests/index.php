<?php
header ("location: ../");
exit;
